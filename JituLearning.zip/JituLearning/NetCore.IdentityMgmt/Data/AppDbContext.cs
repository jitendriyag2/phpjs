﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using NetCore.IdentityMgmt.Data.DbEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCore.IdentityMgmt.Data
{
    public class AppDbContext : IdentityDbContext<AppUser>
    {
        public AppDbContext(DbContextOptions<AppDbContext> options): base(options)
        {

        }

        public DbSet<AppClaim> Claims { get; set; }
        //public DbSet<AppRoleClaim> RoleClaims { get; set; }
        //public DbSet<AppUserClaim> UserClaims { get; set; }
    }
}
