﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCore.IdentityMgmt.Data.DbEntities
{
    [Table("AspNetUserClaims")]
    public class AppUserClaim
    {
        public int Id { get; set; }
        public AppClaim Claim { get; set; }
        public AppUser User { get; set; }
    }
}
