﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace NetCore.IdentityMgmt.Data.DbEntities
{
    [Table("AspNetRoleClaims")]
    public class AppRoleClaim 
    {
        public AppRoleClaim()
        {

        }
        public int Id { get; set; }
        public AppClaim Claim { get; set; }
        public AppUserRole Role { get; set; }
    }
}
