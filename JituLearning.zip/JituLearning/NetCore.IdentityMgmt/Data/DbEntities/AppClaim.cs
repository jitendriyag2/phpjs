﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace NetCore.IdentityMgmt.Data.DbEntities
{
    [Table("AspNetClaims")]
    public class AppClaim
    {
        public byte Id { get; set; }
        public byte Name { get; set; }
        public byte Value { get; set; }
        public bool IsActive { get; set; } = true;
    }
}
