﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using NetCore.IdentityMgmt.Data.DbEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace NetCore.IdentityMgmt.Controllers
{
    public class HomeController :Controller
    {
        private UserManager<AppUser> _userMgr;
        private SignInManager<AppUser> _signinMgr;
        private RoleManager<AppUserRole> _roleMgr;

        public HomeController(UserManager<AppUser> userMgr,
            SignInManager<AppUser> signinMgr,
            RoleManager<AppUserRole> roleMgr)
        {
            _userMgr = userMgr;
            _signinMgr = signinMgr;
            _roleMgr = roleMgr;
        }

        public IActionResult Index()
        {
            return NoContent();
        }

        public void  AddUser()
        {
            AppUser user = new AppUser()
            {
                UserName = "jitu",
                Email = "jitug2a@gamil.com",
                FirstName = "JIt",
                LastName = "Sen"
            };
            var result =_userMgr.CreateAsync(user).Result;
            if(result.Succeeded)
            {
                
            }
        }

        public List<Claim> GetRoleClaims(string RoleName)
        {
            AppUserRole role = _roleMgr.FindByNameAsync(RoleName).Result;
            return _roleMgr.GetClaimsAsync(role).Result.ToList();
        }

        public List<Claim> GetRoleClaims(AppUserRole role)
        {
            return _roleMgr.GetClaimsAsync(role).Result.ToList();
        }

        public AppUserRole GetRole(string RoleName)
        {
            return _roleMgr.FindByNameAsync(RoleName).Result;
        }

        public List<Claim> AddRoleClaims(string RoleName)
        {
            AppUserRole role = _roleMgr.FindByNameAsync(RoleName).Result;
            User.AddIdentity(new ClaimsIdentity() { }
                
                );
            return _roleMgr.GetClaimsAsync(role).Result.ToList();
        }
    }
}
